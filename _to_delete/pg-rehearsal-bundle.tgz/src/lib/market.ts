import {
  MarketQuoteSchema,
  type Quote,
  type UnavailableQuote
} from "../../packages/shared/schemas.js";
import {
  MarketBarsSchema,
  MarketSearchSchema,
  ProviderHealthListSchema
} from "./contracts";
import { api } from "./api";
import type { MarketAsset, MarketBars, ProviderHealth, SymbolSelection } from "./types";

export async function fetchMarketSearch(query: string): Promise<MarketAsset[]> {
  return api.getValidated(
    `/market/search?q=${encodeURIComponent(query)}&limit=20`,
    MarketSearchSchema
  );
}

export async function fetchMarketQuote(symbol: string): Promise<Quote | UnavailableQuote> {
  const normalized = symbol.trim();
  if (!normalized) throw new Error("No symbol selected.");
  return api.getValidated(`/market/quote/${encodeURIComponent(normalized)}`, MarketQuoteSchema);
}

export async function fetchMarketBars(symbol: string, range: string): Promise<MarketBars> {
  const normalized = symbol.trim();
  if (!normalized) throw new Error("No symbol selected.");
  return api.getValidated(
    `/market/bars/${encodeURIComponent(normalized)}?range=${encodeURIComponent(range)}`,
    MarketBarsSchema
  );
}

export async function fetchSymbolSelection(range: string, source: "auto" | "local" | "active"): Promise<SymbolSelection> {
  return api.get<SymbolSelection>(`/selection?range=${encodeURIComponent(range)}&source=${encodeURIComponent(source)}&limit=10`);
}

export function providersFrom(payload: unknown): ProviderHealth[] {
  return ProviderHealthListSchema.parse(payload);
}

export async function fetchProviderHealth() {
  return api.getValidated("/market/health", ProviderHealthListSchema);
}

import crypto from "node:crypto";
import { IntentSubmissionSchema, SWARM_CEILINGS } from "../../packages/shared/swarm.js";
import { AppError } from "../http/errors.js";
import { canonicalHash } from "../research/canonical.js";
import { createRiskEngine } from "../risk/engine.js";
import { DEFAULT_RISK_PROFILE } from "../risk/profile.js";

const TERMINAL = new Set(["filled", "rejected", "broker_rejected"]);
// An intent left mid-submission longer than this is not resubmitted in the
// background: a minutes-old decision at a new price is not what the agent asked
// for. It is reconciled against the ledger and closed out instead.
export const STRANDED_INTENT_MS = 5 * 60 * 1_000;

/** Agent sleeves keep the standard guardrails, tightened to the swarm ceilings. */
export const AGENT_RISK_PROFILE = Object.freeze({
  ...DEFAULT_RISK_PROFILE,
  id: "swarm-agent",
  name: "Swarm agent sleeve",
  rules: {
    ...DEFAULT_RISK_PROFILE.rules,
    maxPositionSize: { enabled: true, percentOfEquity: SWARM_CEILINGS.maxPositionPercent },
    maxSymbolExposure: { enabled: true, percentOfEquity: SWARM_CEILINGS.maxPositionPercent },
    maxConcurrentPositions: { enabled: true, count: SWARM_CEILINGS.maxOpenPositions },
    maxOrdersPerDay: { enabled: true, count: SWARM_CEILINGS.maxIntentsPerDay }
  }
});

function startOfUtcDay(at) {
  const date = new Date(at);
  return Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate());
}

export function createIntentService({
  repositories,
  market,
  broker,
  ledger,
  swarm,
  clock = () => Date.now(),
  idFactory = () => crypto.randomUUID()
}) {
  const repo = repositories.swarm;
  const riskEngine = createRiskEngine(AGENT_RISK_PROFILE);

  async function reject(intent, code, message) {
    const updated = await repo.updateIntent(intent.id, { status: "rejected", rejectCode: code, rejectMessage: message, at: clock() });
    await repositories.audit.append({
      id: idFactory(), at: clock(), actor: `agent:${intent.agentId}`, action: "agent_intent_rejected",
      entity: "agent_intent", entityId: intent.id, detail: { code, message }
    });
    return result(updated);
  }

  function result(intent, extra = {}) {
    return {
      intent: {
        id: intent.id, status: intent.status, symbol: intent.symbol, side: intent.side, qty: intent.qty,
        notionalCents: intent.notionalCents, orderId: intent.orderId, clientOrderId: intent.clientOrderId,
        rejectCode: intent.rejectCode, rejectMessage: intent.rejectMessage, attempts: intent.attempts
      },
      ...extra
    };
  }

  async function finalize(intent, execution) {
    const status = execution.order.status === "filled" ? "filled" : "broker_rejected";
    const updated = await repo.updateIntent(intent.id, {
      status,
      orderId: execution.order.id,
      rejectCode: status === "filled" ? null : execution.order.rejectReason ?? execution.rejection?.code ?? "rejected",
      rejectMessage: status === "filled" ? null : execution.rejection?.message ?? null,
      at: clock()
    });
    await repositories.audit.append({
      id: idFactory(), at: clock(), actor: `agent:${intent.agentId}`, action: `agent_intent_${status}`,
      entity: "agent_intent", entityId: intent.id, detail: { orderId: execution.order.id, decisionId: intent.decisionId }
    });
    return result(updated, { order: execution.order });
  }

  /** Every gate that must still hold at the moment an order would be sent. */
  async function gate(agent, intent) {
    if (!(await swarm.globalIntentsEnabled())) return ["intents_disabled", "Order intents are disabled for the swarm by the operator."];
    const fresh = await repo.getAgent(agent.id);
    if (!fresh.intentsEnabled) return ["intents_disabled", "Order intents are disabled for this agent by the operator."];
    if (fresh.status !== "active") return ["agent_not_active", `Agent is ${fresh.status}.`];
    const decision = intent.decisionId ? await repo.getDecision(intent.decisionId) : null;
    if (!decision || decision.agentId !== agent.id) return ["decision_not_found", "The decision is missing or belongs to another agent."];
    if (decision.symbol !== intent.symbol) return ["decision_mismatch", "The decision is for a different symbol."];
    if (decision.action !== intent.side) return ["decision_mismatch", `The decision was ${decision.action}, not ${intent.side}.`];
    if (clock() - decision.createdAt > SWARM_CEILINGS.maxReportAgeMs) return ["decision_stale", "The decision is older than 24 hours."];
    const plan = await repo.getActivePlan(agent.id);
    if (!plan?.planJson.universe.symbols.includes(intent.symbol)) return ["symbol_not_in_plan", "The symbol is outside the active plan."];
    return null;
  }

  async function size(agent, intent) {
    const quote = await market.getQuote(intent.symbol, { fresh: true });
    const price = Number(quote?.price);
    if (quote?.status !== "real" || !(price > 0)) return { error: ["market_data_unavailable", "A fresh real quote is required."] };
    const portfolio = await broker.portfolio(agent.accountId);
    const equityCents = Number(portfolio.equity ?? portfolio.cash);
    const position = portfolio.positions.find((entry) => entry.symbol === intent.symbol);
    if (intent.side === "buy") {
      const ceilingCents = equityCents * (SWARM_CEILINGS.maxPositionPercent / 100);
      if (Number(intent.notionalCents) + Number(position?.marketValue ?? 0) > ceilingCents) {
        return { error: ["max_position_ceiling", `A position may not exceed ${SWARM_CEILINGS.maxPositionPercent}% of sleeve equity.`] };
      }
      if (!position && portfolio.positions.length >= SWARM_CEILINGS.maxOpenPositions) {
        return { error: ["max_open_positions", `A sleeve may hold at most ${SWARM_CEILINGS.maxOpenPositions} positions.`] };
      }
      const qty = Math.floor((Number(intent.notionalCents) / 100 / price) * 1_000_000);
      return qty > 0 ? { qty, quote } : { error: ["notional_too_small", "The notional buys less than one micro-share."] };
    }
    if (!position) return { error: ["no_position", "Long-only: there is no position to sell."] };
    const held = Number(position.qty);
    const requested = intent.notionalCents ? Math.floor((Number(intent.notionalCents) / 100 / price) * 1_000_000) : held;
    return { qty: Math.min(held, requested), quote };
  }

  async function send(agent, intent, qty, quote) {
    const submitting = await repo.updateIntent(intent.id, { status: "submitting", qty, attempt: true, at: clock() });
    const execution = await broker.submitOrder({
      clientOrderId: intent.clientOrderId,
      accountId: agent.accountId,
      symbol: intent.symbol,
      side: intent.side,
      qty,
      quote,
      riskEngine,
      signalReason: `agent:${agent.name} decision:${intent.decisionId}`
    });
    return finalize(submitting, execution);
  }

  /**
   * Brings an intent to a terminal state without ever creating a second order:
   * the client order id is derived from the intent id, and the ledger is unique
   * on it, so a retry either finds the order that was already written or sends
   * the first one.
   */
  async function reconcile(agent, intent, { resubmit = true } = {}) {
    if (TERMINAL.has(intent.status)) return result(intent, { idempotent: true });
    const existing = await ledger.getExecution(intent.clientOrderId);
    if (existing) return finalize(intent, existing);
    if (intent.status === "submitting") {
      if (!resubmit) return reject(intent, "submission_interrupted", "Submission was interrupted before the ledger recorded an order; nothing was traded.");
      const blocked = await gate(agent, intent);
      if (blocked) return reject(intent, ...blocked);
      return send(agent, intent, Number(intent.qty), undefined);
    }
    return process(agent, intent);
  }

  async function process(agent, intent) {
    const blocked = await gate(agent, intent);
    if (blocked) return reject(intent, ...blocked);
    const today = await repo.countIntentsSince(agent.id, startOfUtcDay(clock()));
    if (today > SWARM_CEILINGS.maxIntentsPerDay) return reject(intent, "max_intents_per_day", `At most ${SWARM_CEILINGS.maxIntentsPerDay} intents per day.`);
    let sized;
    try { sized = await size(agent, intent); }
    catch (error) { return reject(intent, "market_data_unavailable", error.message); }
    if (sized.error) return reject(intent, ...sized.error);
    return send(agent, intent, sized.qty, sized.quote);
  }

  async function submit(agent, input) {
    const parsed = IntentSubmissionSchema.safeParse(input);
    if (!parsed.success) throw new AppError("INTENT_INVALID", "Request validation failed.", 422, parsed.error.flatten());
    const { idempotencyKey, ...request } = parsed.data;
    const requestHash = canonicalHash(request);
    const existing = await repo.getIntentByKey(agent.id, idempotencyKey);
    if (existing) {
      if (existing.requestHash !== requestHash) throw new AppError("IDEMPOTENCY_KEY_REUSED", "That idempotency key was used for a different intent.", 409);
      return reconcile(agent, existing);
    }
    const id = idFactory();
    const intent = await repo.insertIntent({
      id, agentId: agent.id, decisionId: request.decisionId, idempotencyKey, requestHash, symbol: request.symbol, side: request.side,
      notionalCents: request.notional === undefined ? null : Math.round(request.notional * 100), clientOrderId: `intent:${id}`, createdAt: clock()
    });
    if (intent.id !== id) return reconcile(agent, intent); // lost a concurrent insert race
    return process(agent, intent);
  }

  /** Background sweep: no intent stays stranded mid-submission. */
  async function reconcileStranded() {
    const rows = await repositories.swarm.listIntentsByStatus?.(["received", "submitting"], clock() - STRANDED_INTENT_MS) ?? [];
    const outcomes = [];
    for (const intent of rows) {
      const agent = await repo.getAgent(intent.agentId);
      outcomes.push(await reconcile(agent, intent, { resubmit: false }));
    }
    return outcomes;
  }

  return Object.freeze({ submit, reconcile, reconcileStranded, riskEngine });
}

import crypto from "node:crypto";

export const SUPERVISOR_LEASE = "swarm-supervisor";
const LEASE_TTL_MS = 3 * 60 * 1_000;
const WEEKDAY = { Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6, Sun: 7 };

function zonedParts(at, timeZone) {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone, year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", weekday: "short", hourCycle: "h23"
  }).formatToParts(at);
  return Object.fromEntries(parts.filter((part) => part.type !== "literal").map((part) => [part.type, part.value]));
}

/** UTC instant of a wall-clock time in a zone (DST-correct for whole-minute zones). */
export function zonedInstant({ year, month, day, hour, minute }, timeZone) {
  let guess = Date.UTC(year, month - 1, day, hour, minute);
  for (let pass = 0; pass < 2; pass += 1) {
    const parts = zonedParts(guess, timeZone);
    const asUtc = Date.UTC(Number(parts.year), Number(parts.month) - 1, Number(parts.day), Number(parts.hour), Number(parts.minute));
    guess -= asUtc - Date.UTC(year, month - 1, day, hour, minute);
  }
  return guess;
}

/**
 * The cadence slots that are open at `now`. Only the current window is ever
 * returned, so a supervisor that was down does not backfill a burst of stale
 * research cycles when it comes back.
 */
export function openSlots(plan, now) {
  const slots = [];
  plan.cadence.forEach((entry, index) => {
    const windowMs = entry.expiresAfterMinutes * 60_000;
    const { schedule } = entry;
    if (schedule.type === "interval") {
      const periodMs = schedule.minutes * 60_000;
      const start = Math.floor(now / periodMs) * periodMs;
      const end = start + Math.min(windowMs, periodMs);
      if (now < end) slots.push({ kind: entry.task, slot: `interval:${index}:${start}`, dueAt: start, expiresAt: end });
      return;
    }
    const parts = zonedParts(now, schedule.timezone);
    if (!schedule.weekdays.includes(WEEKDAY[parts.weekday])) return;
    const [hour, minute] = schedule.at.split(":").map(Number);
    const dueAt = zonedInstant({ year: Number(parts.year), month: Number(parts.month), day: Number(parts.day), hour, minute }, schedule.timezone);
    if (now >= dueAt && now < dueAt + windowMs) {
      slots.push({ kind: entry.task, slot: `daily:${index}:${parts.year}-${parts.month}-${parts.day}`, dueAt, expiresAt: dueAt + windowMs });
    }
  });
  return slots;
}

export function createSwarmScheduler({
  repositories,
  intents,
  clock = () => Date.now(),
  idFactory = () => crypto.randomUUID(),
  holder = `supervisor:${crypto.randomUUID()}`,
  intervalMs = 60_000,
  logger = console
}) {
  const repo = repositories.swarm;
  let timer = null;
  let running = null;

  async function tick() {
    const at = clock();
    const leader = await repo.acquireLease({ name: SUPERVISOR_LEASE, holder, at, ttlMs: LEASE_TTL_MS });
    if (!leader) return { leader: false, created: 0, expired: 0, reconciled: 0 };
    const expired = await repo.expireTasks(at);
    let created = 0;
    for (const agent of await repo.listAgents()) {
      if (agent.status !== "active") continue;
      const plan = await repo.getActivePlan(agent.id);
      if (!plan) continue;
      for (const slot of openSlots(plan.planJson, at)) {
        const inserted = await repo.insertTask({
          id: idFactory(), agentId: agent.id, planId: plan.id, ...slot, createdBy: "scheduler", createdAt: at
        });
        if (inserted) created += 1;
      }
    }
    const reconciled = intents ? (await intents.reconcileStranded()).length : 0;
    return { leader: true, created, expired, reconciled };
  }

  function start() {
    if (timer) return;
    const run = () => {
      if (running) return;
      running = tick().catch((error) => logger.error?.("Swarm scheduler tick failed:", error)).finally(() => { running = null; });
    };
    timer = setInterval(run, intervalMs);
    timer.unref?.();
    run();
  }

  async function stop() {
    if (timer) clearInterval(timer);
    timer = null;
    await running;
    await repo.releaseLease({ name: SUPERVISOR_LEASE, holder });
  }

  return Object.freeze({ tick, start, stop, holder });
}

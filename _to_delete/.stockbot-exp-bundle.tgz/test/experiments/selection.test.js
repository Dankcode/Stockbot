import assert from "node:assert/strict";
import test from "node:test";

import {
  DEFAULT_GATES,
  factsFromBars,
  rankCandidates,
  recommendSymbols,
  renderRecommendations,
  scoreCandidate
} from "../../server/experiments/selection.js";

function goodFacts(overrides = {}) {
  return {
    symbol: "GOOD",
    price: 120,
    barCount: 400,
    medianDollarVolume: 800_000_000,
    atrPercent: 2.5,
    trendStrength: 0.25,
    researchDocumentCount: 10,
    researchSources: [{ id: "sec-edgar", retrievedAt: 1_700_000_000_000, snapshotId: "snap-1" }],
    ...overrides
  };
}

test("a liquid, moving, well-covered symbol scores near the top of the range", () => {
  const scored = scoreCandidate(goodFacts());
  assert.equal(scored.eligible, true);
  assert.ok(scored.score > 0.8, `expected > 0.8, got ${scored.score}`);
  assert.equal(scored.evidence.length, 1);
  assert.match(scored.reasons.join(" "), /liquidity/);
});

test("gates exclude rather than merely penalise", () => {
  const thin = scoreCandidate(goodFacts({ symbol: "THIN", medianDollarVolume: 500_000 }));
  assert.equal(thin.eligible, false);
  assert.match(thin.blockers.join(" "), /below the \$20M floor/);

  const penny = scoreCandidate(goodFacts({ symbol: "PENNY", price: 1.2 }));
  assert.equal(penny.eligible, false);
  assert.match(penny.blockers.join(" "), /below the 5 floor/);

  const short = scoreCandidate(goodFacts({ symbol: "NEW", barCount: 30 }));
  assert.equal(short.eligible, false);
  assert.match(short.blockers.join(" "), /30 bars of history/);
});

test("missing data shrinks the denominator instead of scoring as neutral", () => {
  const partial = scoreCandidate(goodFacts({ atrPercent: null, researchDocumentCount: null }));
  assert.deepEqual([...partial.unmeasured].sort(), ["researchCoverage", "volatility"]);
  assert.match(partial.reasons.join(" "), /not measured/);
  // Liquidity and trend are both strong, so dropping the unmeasured weights must not
  // drag the score down toward zero the way a 0-default would.
  assert.ok(partial.score > 0.8, `expected > 0.8, got ${partial.score}`);
});

test("volatility is a band, not a ramp — a dead symbol and a wild one both score low", () => {
  const dead = scoreCandidate(goodFacts({ atrPercent: 0.2 }));
  const wild = scoreCandidate(goodFacts({ atrPercent: 9 }));
  const ideal = scoreCandidate(goodFacts({ atrPercent: 2.5 }));
  assert.equal(dead.components.volatility, 0);
  assert.equal(wild.components.volatility, 0);
  assert.equal(ideal.components.volatility, 1);
});

test("ranking separates eligible from excluded and reports the leader's margin", () => {
  const ranked = rankCandidates([
    goodFacts({ symbol: "AAA" }),
    goodFacts({ symbol: "BBB", atrPercent: 1.0, trendStrength: 0.05, researchDocumentCount: 1 }),
    goodFacts({ symbol: "THIN", medianDollarVolume: 100_000 })
  ], { limit: 5 });

  assert.deepEqual(ranked.recommended.map((entry) => entry.symbol), ["AAA", "BBB"]);
  assert.equal(ranked.eligibleCount, 2);
  assert.deepEqual(ranked.excluded.map((entry) => entry.symbol), ["THIN"]);
  assert.ok(ranked.separation > 0);
});

test("separation is null with fewer than two eligible candidates", () => {
  assert.equal(rankCandidates([goodFacts()]).separation, null);
  assert.equal(rankCandidates([]).recommended.length, 0);
});

test("factsFromBars derives price, liquidity, volatility and trend from a bar series", () => {
  const bars = Array.from({ length: 300 }, (_, index) => {
    const close = 100 + index * 0.2;
    return { time: index * 86_400_000, open: close - 0.5, high: close + 1, low: close - 1, close, volume: 5_000_000 };
  });
  const facts = factsFromBars({ symbol: "trend", bars, research: { documentCount: 4, sources: [{ id: "rss" }] } });
  assert.equal(facts.symbol, "TREND");
  assert.equal(facts.barCount, 300);
  assert.equal(facts.price, bars.at(-1).close);
  assert.ok(facts.medianDollarVolume > 700_000_000);
  assert.ok(facts.atrPercent > 0 && facts.atrPercent < 5);
  // Rising series ends above its 200-bar mean.
  assert.ok(facts.trendStrength > 0);
  assert.equal(facts.researchDocumentCount, 4);
});

test("recommendSymbols skips symbols whose bars fail and records why", async () => {
  const bars = Array.from({ length: 300 }, (_, index) => {
    const close = 100 + Math.sin(index / 9) * 12 + index * 0.15;
    return { time: index * 86_400_000, open: close, high: close + 2, low: close - 2, close, volume: 6_000_000 };
  });
  const result = await recommendSymbols({
    universe: ["aapl", "AAPL", "BROKE", "NVDA"],
    getBars: async (symbol) => {
      if (symbol === "BROKE") throw new Error("Real historical bars unavailable.");
      return { bars };
    },
    limit: 2
  });
  assert.equal(result.requested, 3, "duplicates are collapsed before fetching");
  assert.equal(result.scored, 2);
  assert.equal(result.errors.length, 1);
  assert.equal(result.errors[0].stage, "bars");
  assert.match(renderRecommendations(result), /not a prediction/);
});

test("a research adapter that throws degrades coverage instead of dropping the symbol", async () => {
  const bars = Array.from({ length: 300 }, (_, index) => ({
    time: index * 86_400_000, open: 100, high: 103, low: 98, close: 100 + index * 0.1, volume: 6_000_000
  }));
  const result = await recommendSymbols({
    universe: ["AAPL"],
    getBars: async () => ({ bars }),
    getResearch: async () => { throw new Error("RESEARCH_SOURCE_NOT_CONFIGURED"); }
  });
  assert.equal(result.scored, 1);
  assert.equal(result.errors[0].stage, "research");
  assert.ok(result.recommended[0].unmeasured.includes("researchCoverage"));
});

test("the default gates are the documented ones and are frozen", () => {
  assert.equal(DEFAULT_GATES.minMedianDollarVolume, 20_000_000);
  assert.ok(Object.isFrozen(DEFAULT_GATES));
});
